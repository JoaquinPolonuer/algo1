//
// Created by Pablo on 22/11/2017.
//

#ifndef CLION_CARCAJADAS_H
#define CLION_CARCAJADAS_H

#include <vector>
#include <iostream>
using namespace std;

vector<char> leerDatos(string s);

int leerLargoReal(string filename);

int risaMasLarga(vector<char> s);


#endif //CLION_CARCAJADAS_H
